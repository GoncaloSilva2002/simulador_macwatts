const TABLES = new Set(["preco_configuracao", "preco_bateria", "preco_backup"]);

async function getAdminPrices() {
  const [gammas, configs, configPrices, batteries, batteryPrices, backups, backupPrices] = await Promise.all([
    query("gama", "select=id,nome&order=id"),
    query("configuracao", "select=id,num_paineis,id_tipo_luz,inversor&order=num_paineis"),
    query("preco_configuracao", "select=id,preco,id_configuracao,id_gama&order=id"),
    query("bateria", "select=id,potencia&order=potencia"),
    query("preco_bateria", "select=id,preco,id_bateria,id_gama&order=id"),
    query("backup", "select=id,nome,num_paineis,id_tipo_luz&order=num_paineis"),
    query("preco_backup", "select=id,preco,id_backup,id_gama&order=id")
  ]);

  const gamaById = new Map(gammas.map((row) => [Number(row.id), row.nome]));
  const configById = new Map(configs.map((row) => [Number(row.id), row]));
  const batteryById = new Map(batteries.map((row) => [Number(row.id), row]));
  const backupById = new Map(backups.map((row) => [Number(row.id), row]));
  backups.forEach((backup) => {
    const phase = Number(backup.id_tipo_luz) === 2 ? "Trifásico" : "Monofásico";
    backup.nome = `${backup.nome || `${backup.num_paineis} painéis`} · ${phase}`;
  });

  return [
    ...configPrices.map((row) => { const config = configById.get(Number(row.id_configuracao)); return { id: row.id, table: "preco_configuracao", category: "Painéis / configuração", label: configLabel(config), gama: gamaById.get(Number(row.id_gama)) || row.id_gama, price: Number(row.preco || 0), inverter: config?.inversor || "", configId: config?.id }; }),
    ...batteryPrices.map((row) => ({ id: row.id, table: "preco_bateria", category: "Bateria", label: `${batteryById.get(Number(row.id_bateria))?.potencia ?? row.id_bateria} kWh`, gama: gamaById.get(Number(row.id_gama)) || row.id_gama, price: Number(row.preco || 0) })),
    ...backupPrices.map((row) => { const backup = backupById.get(Number(row.id_backup)); return { id: row.id, table: "preco_backup", category: "Backup", label: backup?.nome || `${backup?.num_paineis ?? row.id_backup} painéis`, gama: gamaById.get(Number(row.id_gama)) || row.id_gama, price: Number(row.preco || 0), panels: Number(backup?.num_paineis), phase: Number(backup?.id_tipo_luz) === 2 ? "Trifásico" : "Monofásico" }; })
  ];
}

async function updateAdminPrice(table, id, price) {
  if (!TABLES.has(table)) throw new Error("Tabela de preços inválida.");
  const numericId = Number(id);
  const numericPrice = Number(price);
  if (!Number.isInteger(numericId) || !Number.isFinite(numericPrice) || numericPrice < 0) {
    throw new Error("Preço inválido.");
  }
  await request(table, `id=eq.${encodeURIComponent(numericId)}`, "PATCH", { preco: numericPrice });
}

async function updateAdminInverter(id, inverter) {
  const numericId = Number(id);
  if (!Number.isInteger(numericId) || String(inverter ?? "").length > 250) throw new Error("Inversor inválido.");
  await request("configuracao", `id=eq.${encodeURIComponent(numericId)}`, "PATCH", { inversor: String(inverter ?? "").trim() });
}

function configLabel(row) {
  if (!row) return "Configuração";
  const phase = Number(row.id_tipo_luz) === 2 ? "Trifásico" : "Monofásico";
  return `${row.num_paineis} painéis · ${phase}`;
}

async function query(table, search) {
  return request(table, search, "GET");
}

async function request(table, search, method, body) {
  const url = String(process.env.SUPABASE_URL || "").trim().replace(/\/+$/, "");
  const key = String(process.env.SUPABASE_SERVICE_ROLE_KEY || "").trim();
  if (!url || !key) throw new Error("Supabase não configurado no servidor.");
  const response = await fetch(`${url}/rest/v1/${table}?${search}`, {
    method,
    headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json", Prefer: "return=minimal" },
    ...(body === undefined ? {} : { body: JSON.stringify(body) })
  });
  if (!response.ok) throw new Error(`Supabase: ${await response.text()}`);
  if (method === "GET") return response.json();
}

module.exports = { getAdminPrices, updateAdminPrice, updateAdminInverter };
